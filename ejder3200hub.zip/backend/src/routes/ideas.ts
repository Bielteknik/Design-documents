

import { Router } from 'express';
import { prisma } from '../prisma';

const router = Router();

// GET all ideas
router.get('/', async (req, res, next) => {
  try {
    const ideas = await prisma.idea.findMany({
      include: {
        author: true,
        projectLeader: true,
        potentialTeam: {
            select: { id: true }
        }
      },
    });
     const ideasWithTeamIds = ideas.map(idea => ({
        ...idea,
        potentialTeam: idea.potentialTeam.map(member => member.id)
    }));
    res.json(ideasWithTeamIds);
  } catch (error) {
    next(error);
  }
});

// POST a new idea
router.post('/', async (req, res, next) => {
    const { authorId, projectLeaderId, potentialTeam, ...rest } = req.body;
    try {
        const idea = await prisma.idea.create({
            data: {
                ...rest,
                // FIX: Replaced enum with string literal to avoid dependency on generated types.
                status: 'New',
                creationDate: new Date().toISOString(),
                author: { connect: { id: authorId } },
                ...(projectLeaderId && { projectLeader: { connect: { id: projectLeaderId } } }),
                ...(potentialTeam && { potentialTeam: { connect: potentialTeam.map((id: string) => ({ id })) } }),
            },
            include: { author: true, projectLeader: true, potentialTeam: { select: { id: true } } },
        });
        const ideaWithTeamIds = { ...idea, potentialTeam: idea.potentialTeam.map(m => m.id) };
        res.status(201).json(ideaWithTeamIds);
    } catch(error) {
        next(error);
    }
});

// PUT update an idea
router.put('/:id', async (req, res, next) => {
    const { id } = req.params;
    const { authorId, projectLeaderId, potentialTeam, ...rest } = req.body;
    try {
        const idea = await prisma.idea.update({
            where: { id },
            data: {
                ...rest,
                 ...(authorId && { author: { connect: { id: authorId } } }),
                ...(projectLeaderId && { projectLeader: { connect: { id: projectLeaderId } } }),
                ...(potentialTeam && { potentialTeam: { set: potentialTeam.map((id: string) => ({ id })) } }),
            },
            include: { author: true, projectLeader: true, potentialTeam: { select: { id: true } } },
        });
        const ideaWithTeamIds = { ...idea, potentialTeam: idea.potentialTeam.map(m => m.id) };
        res.json(ideaWithTeamIds);
    } catch (error) {
        next(error);
    }
});

// DELETE an idea
router.delete('/:id', async (req, res, next) => {
    const { id } = req.params;
    try {
        await prisma.idea.delete({ where: { id } });
        res.json({ success: true });
    } catch (error) {
        next(error);
    }
});

export default router;