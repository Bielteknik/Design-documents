
import { Router } from 'express';
import { prisma } from '../prisma';

const router = Router();

// GET all projects
router.get('/', async (req, res, next) => {
  try {
    const projects = await prisma.project.findMany({
      include: {
        manager: true,
        team: {
          select: { id: true }
        },
      },
    });
    const projectsWithTeamIds = projects.map(p => ({
        ...p,
        team: p.team.map(member => member.id)
    }));
    res.json(projectsWithTeamIds);
  } catch (error) {
    next(error);
  }
});

// GET one project by ID
router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const project = await prisma.project.findUnique({
      where: { id },
      include: {
        manager: true,
        team: {
          select: { id: true }
        },
        tasks: true,
        comments: { include: { author: true } },
        evaluations: { include: { author: true } },
      },
    });
    if (project) {
       const projectWithTeamIds = {
           ...project,
           team: project.team.map(member => member.id)
       };
      res.json(projectWithTeamIds);
    } else {
      res.status(404).json({ error: 'Project not found' });
    }
  } catch (error) {
    next(error);
  }
});

// POST a new project
router.post('/', async (req, res, next) => {
    const { managerId, teamIds, ...rest } = req.body;
    try {
        const project = await prisma.project.create({
            data: {
                ...rest,
                manager: { connect: { id: managerId } },
                team: { connect: teamIds?.map((id: string) => ({ id })) || [] },
            },
            include: { manager: true, team: { select: { id: true } } },
        });
        const projectWithTeamIds = { ...project, team: project.team.map(m => m.id) };
        res.status(201).json(projectWithTeamIds);
    } catch(error) {
        next(error);
    }
});

// PUT update a project
router.put('/:id', async (req, res, next) => {
    const { id } = req.params;
    const { managerId, teamIds, ...rest } = req.body;
    try {
        const project = await prisma.project.update({
            where: { id },
            data: {
                ...rest,
                ...(managerId && { manager: { connect: { id: managerId } } }),
                ...(teamIds && { team: { set: teamIds.map((id: string) => ({ id })) } }),
            },
            include: { manager: true, team: { select: { id: true } } },
        });
        const projectWithTeamIds = { ...project, team: project.team.map(m => m.id) };
        res.json(projectWithTeamIds);
    } catch (error) {
        next(error);
    }
});

// DELETE a project
router.delete('/:id', async (req, res, next) => {
    const { id } = req.params;
    try {
        await prisma.project.delete({ where: { id } });
        res.status(204).send();
    } catch (error) {
        next(error);
    }
});


export default router;