
import { Router } from 'express';
import { prisma } from '../prisma';

const router = Router();

// GET all events
router.get('/', async (req, res, next) => {
  try {
    const events = await prisma.event.findMany({
      include: {
        participants: { select: { id: true } },
        assignee: true,
        reporter: true,
        project: true,
        idea: true,
      },
    });
    const eventsWithParticipantIds = events.map(event => ({
        ...event,
        participants: event.participants.map(p => p.id)
    }));
    res.json(eventsWithParticipantIds);
  } catch (error) {
    next(error);
  }
});

// POST a new event
router.post('/', async (req, res, next) => {
    const { participants, assigneeId, reporterId, projectId, ideaId, ...rest } = req.body;
    try {
        const event = await prisma.event.create({
            data: {
                ...rest,
                ...(participants && { participants: { connect: participants.map((id: string) => ({ id })) } }),
                ...(assigneeId && { assignee: { connect: { id: assigneeId } } }),
                ...(reporterId && { reporter: { connect: { id: reporterId } } }),
                ...(projectId && { project: { connect: { id: projectId } } }),
                ...(ideaId && { idea: { connect: { id: ideaId } } }),
            },
            include: { participants: { select: { id: true } }, assignee: true, project: true, idea: true },
        });
        const eventWithIds = { ...event, participants: event.participants.map(p => p.id) };
        res.status(201).json(eventWithIds);
    } catch(error) {
        next(error);
    }
});

// PUT update an event
router.put('/:id', async (req, res, next) => {
    const { id } = req.params;
    const { participants, assigneeId, ...rest } = req.body;
    try {
        const event = await prisma.event.update({
            where: { id },
            data: {
                ...rest,
                ...(participants && { participants: { set: participants.map((id: string) => ({ id })) } }),
                 ...(assigneeId && { assignee: { connect: { id: assigneeId } } }),
            },
             include: { participants: { select: { id: true } }, assignee: true, project: true, idea: true },
        });
        const eventWithIds = { ...event, participants: event.participants.map(p => p.id) };
        res.json(eventWithIds);
    } catch (error) {
        next(error);
    }
});

// DELETE an event
router.delete('/:id', async (req, res, next) => {
    const { id } = req.params;
    try {
        await prisma.event.delete({ where: { id } });
        res.status(204).send();
    } catch (error) {
        next(error);
    }
});

export default router;